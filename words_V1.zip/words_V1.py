"""
Aiden Weldon
Purpose: to create a program that will open a text file and then display a random word from said file
11/10/2025
"""

#import library
import random

#function: open_file
#purpose: to open the text file
def open_file():
    inputfile = open("words.txt", "r")
    return inputfile
#function: close_file
#purpose: to close the text file
def close_file(inputfile):
    inputfile.close()
    
# Function: pick_random_word_from_file
# Purpose: Read words from an open file, selects and returns one random word
def pick_random_word_from_file(inputfile):
# Creates an empty list for storing valid words from the file
    words = []
# Loops through the file to read each line
    for line in inputfile:
        fileContent = line.split()
        words.extend(fileContent)
    return random.choice(words)

#main function
def main():
    print("Welcome to the Build-a-Snowman/Robot Game!")
    
    # PART 1: Basic file handling
    try:
        inputfile= open_file()
        secret_word = pick_random_word_from_file(inputfile)
        close_file(inputfile)
    except FileNotFoundError:
        print("Error: 'words.txt' not found.")
        return
    # Checks that the file is not empty by ensuring there is something stored in secret word
    if not secret_word:
        print("Error: No valid words found in the file.")
        return 
    # Display the random word chosen and the number of letters in the word
    print("Word to guess:", secret_word)
    print(f"(The secret word had {len(secret_word)} letters)")
# Run the program
if __name__ == "__main__":
    main()

        